Spatialite & Rasterlite Tools

v4.3/1.1g

I'm too lazy to do anything fancy for this.

Copy them wherever you like.  /usr/local/bin is a good place.

SQLite3 framework v3.14.1+ required.


exif_loader, shp_doctor, and all spatialite_* tools are released under the GPL.

All the rasterlite_* tools are released under the MPL.


- William Kyngesburye
kyngchaos@kyngchaos.com
http://www.kyngchaos.com/
